import vlc
import sys
from PIL import ImageTk

try:
    import Tkinter as tk
    from Tkinter import ttk
    from Tkinter.filedialog import askopenfilename
except ImportError:
    import tkinter as tk
    from tkinter import ttk
    from tkinter.filedialog import askopenfilename
'''
if sys.version_info[0] < 3:
    import Tkinter as Tk
    from Tkinter import ttk
    from Tkinter.filedialog import askopenfilename
else:
    import tkinter as Tk
    from tkinter import ttk
    from tkinter.filedialog import askopenfilename'''

import os
import pathlib                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
import platform
from threading import Timer,Thread,Event
import time
import platform
import slideshow02 as sl

instance = vlc.Instance('--mouse-hide-timeout=0', '--fullscreen', '--repeat')
player = instance.media_player_new()
media = instance.media_new()


class Application(Frame):
    def PlayVlc(self):
        self.media.get_mrl()
        self.player.set_fullscreen(True)
        self.player.set_media(media)
        self.player.play()
        self.player.audio_set_volume(0)

    def playVlcNotFullscrn(self):
        self.media.get_mrl()
        self.player.set_media(media)
        self.player.play()
        self.player.audio_set_volume(0)
        
    def createWidgets(self):
        '''part of button quit'''
        self.QUIT = Button(self)
        self.QUIT["text"] = "QUIT"
        self.QUIT["fg"]   = "red"
        self.QUIT["command"] =  self.quit

        self.QUIT.pack({"side": "right"})

        #part of full screen
        self.hi_there = Button(self)
        self.hi_there["text"] = "PLAY FULL SCREEN"
        self.hi_there["command"] = self.sl

        self.hi_there.pack({"side": "left"})

        #part of default
        self.getPlay = Button(self)
        self.getPlay["text"] = "PLAY DEFUALT WINDOW"
        self.getPlay["command"] = self.playVlcNotFullscrn

        self.getPlay.pack({"side": "left"})
        

    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.pack()
        self.createWidgets()