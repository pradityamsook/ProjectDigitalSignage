import vlc
p = vlc.MediaPlayer("https://www.youtube.com/watch?v=Rq1TW5PlbEY")
p.play()
