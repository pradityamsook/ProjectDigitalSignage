import datetime
import time

toDay = datetime.datetime.today()
day = datetime.datetime(2016, 12, 24, 11, 50, 00)
print(toDay)



if toDay == day:
    print("real time")
   
