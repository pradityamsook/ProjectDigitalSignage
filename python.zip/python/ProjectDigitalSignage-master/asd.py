


import Tkinter as Tk
from Tkinter import ttk
from Tkinter.filedialog import askopenfilename

from PIL import ImageTk

root = Tk()

# make it cover the entire screen
w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.overrideredirect(1)
root.geometry("%dx%d+0+0" % (w, h))