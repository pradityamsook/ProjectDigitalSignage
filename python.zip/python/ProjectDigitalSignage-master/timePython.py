import time
def timing():
    while True != False:

        y = time.strftime("%H"+":"+"%M"+":"+"%S")
        print(y)

        time.sleep(1)

        x = str("10"+":"+"40"+":"+"00")
        x = y
        if x == y:
            print("realtime")



